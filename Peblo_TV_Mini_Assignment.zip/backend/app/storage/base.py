from abc import ABC, abstractmethod
from typing import Optional

class Storage(ABC):
    """
    Abstract Storage Interface for storing, retrieving, and deleting binary assets.
    Enables pluggable storage backends (LocalStorage, Cloudflare R2 / S3) without modifying business logic.
    """

    @abstractmethod
    def upload(self, data: bytes, relative_path: str, content_type: str = "application/octet-stream") -> str:
        """Uploads file bytes to relative_path and returns the accessible URL."""
        pass

    @abstractmethod
    def delete(self, relative_path: str) -> bool:
        """Deletes file at relative_path. Returns True if deleted, False otherwise."""
        pass

    @abstractmethod
    def exists(self, relative_path: str) -> bool:
        """Checks whether file exists at relative_path."""
        pass

    @abstractmethod
    def get_url(self, relative_path: str) -> str:
        """Returns the public or API URL for accessing the file."""
        pass

    @abstractmethod
    def get_bytes(self, relative_path: str) -> Optional[bytes]:
        """Fetches raw bytes for a file, or returns None if not found."""
        pass

    @abstractmethod
    def save_atomic(self, data: bytes, relative_path: str, content_type: str = "application/json") -> str:
        """Atomically saves data so readers never see partial writes."""
        pass
