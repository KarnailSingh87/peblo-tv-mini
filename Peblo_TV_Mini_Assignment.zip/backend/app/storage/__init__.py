from typing import Optional
from backend.app.core.config import settings
from backend.app.storage.base import Storage
from backend.app.storage.local import LocalStorage

_storage_instance: Optional[Storage] = None

def get_storage() -> Storage:
    """Returns the singleton storage instance based on STORAGE_TYPE."""
    global _storage_instance
    if _storage_instance is None:
        if getattr(settings, "STORAGE_TYPE", "local") in ["r2", "s3"]:
            from backend.app.storage.r2 import R2Storage
            _storage_instance = R2Storage()
        else:
            _storage_instance = LocalStorage()
    return _storage_instance

__all__ = ["Storage", "LocalStorage", "get_storage"]
