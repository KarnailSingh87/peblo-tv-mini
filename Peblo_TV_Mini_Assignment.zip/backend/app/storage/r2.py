from typing import Optional
from backend.app.core.config import settings
from backend.app.storage.base import Storage

class R2Storage(Storage):
    """
    Cloudflare R2 / AWS S3 Storage implementation.
    Single-object PUT operations in S3/R2 are inherently atomic.
    """

    def __init__(self):
        import boto3
        from botocore.config import Config

        self.bucket = settings.S3_BUCKET_NAME
        self.public_base_url = settings.S3_PUBLIC_BASE_URL.rstrip("/")
        self.s3_client = boto3.client(
            "s3",
            endpoint_url=settings.S3_ENDPOINT_URL or None,
            aws_access_key_id=settings.S3_ACCESS_KEY_ID or None,
            aws_secret_access_key=settings.S3_SECRET_ACCESS_KEY or None,
            region_name=settings.S3_REGION_NAME or "auto",
            config=Config(signature_version="s3v4")
        )

    def upload(self, data: bytes, relative_path: str, content_type: str = "application/octet-stream") -> str:
        clean_rel = relative_path.lstrip("/").replace("\\", "/")
        self.s3_client.put_object(
            Bucket=self.bucket,
            Key=clean_rel,
            Body=data,
            ContentType=content_type
        )
        return self.get_url(clean_rel)

    def save_atomic(self, data: bytes, relative_path: str, content_type: str = "application/json") -> str:
        return self.upload(data, relative_path, content_type)

    def get_bytes(self, relative_path: str) -> Optional[bytes]:
        clean_rel = relative_path.lstrip("/").replace("\\", "/")
        try:
            resp = self.s3_client.get_object(Bucket=self.bucket, Key=clean_rel)
            return resp["Body"].read()
        except Exception:
            return None

    def exists(self, relative_path: str) -> bool:
        clean_rel = relative_path.lstrip("/").replace("\\", "/")
        try:
            self.s3_client.head_object(Bucket=self.bucket, Key=clean_rel)
            return True
        except Exception:
            return False

    def delete(self, relative_path: str) -> bool:
        clean_rel = relative_path.lstrip("/").replace("\\", "/")
        try:
            self.s3_client.delete_object(Bucket=self.bucket, Key=clean_rel)
            return True
        except Exception:
            return False

    def get_url(self, relative_path: str) -> str:
        clean_rel = relative_path.lstrip("/").replace("\\", "/")
        if self.public_base_url:
            return f"{self.public_base_url}/{clean_rel}"
        return f"https://{self.bucket}.r2.cloudflarestorage.com/{clean_rel}"
