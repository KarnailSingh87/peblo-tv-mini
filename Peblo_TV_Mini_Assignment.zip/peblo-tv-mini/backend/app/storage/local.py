import os
from typing import Optional
from backend.app.core.config import settings
from backend.app.storage.base import Storage

class LocalStorage(Storage):
    """
    Local filesystem storage implementation.
    Safely resolves paths within LOCAL_STORAGE_DIR to prevent path traversal attacks.
    """

    def __init__(self, base_dir: Optional[str] = None):
        self.base_dir = os.path.abspath(base_dir or settings.LOCAL_STORAGE_DIR)
        os.makedirs(self.base_dir, exist_ok=True)

    def _resolve_safe_path(self, relative_path: str) -> str:
        clean_rel = relative_path.lstrip("/").replace("\\", "/")
        full_path = os.path.abspath(os.path.join(self.base_dir, clean_rel))
        # Prevent directory traversal outside base_dir
        if not full_path.startswith(self.base_dir):
            raise ValueError(f"Security error: Path traversal detected for path '{relative_path}'")
        return full_path

    def upload(self, data: bytes, relative_path: str, content_type: str = "application/octet-stream") -> str:
        full_path = self._resolve_safe_path(relative_path)
        os.makedirs(os.path.dirname(full_path), exist_ok=True)
        with open(full_path, "wb") as f:
            f.write(data)
        return self.get_url(relative_path)

    def delete(self, relative_path: str) -> bool:
        try:
            full_path = self._resolve_safe_path(relative_path)
            if os.path.exists(full_path):
                os.remove(full_path)
                return True
            return False
        except Exception:
            return False

    def exists(self, relative_path: str) -> bool:
        try:
            full_path = self._resolve_safe_path(relative_path)
            return os.path.exists(full_path)
        except Exception:
            return False

    def get_url(self, relative_path: str) -> str:
        clean_rel = relative_path.lstrip("/").replace("\\", "/")
        return f"{settings.API_V1_STR}/storage/{clean_rel}"

    def get_bytes(self, relative_path: str) -> Optional[bytes]:
        try:
            full_path = self._resolve_safe_path(relative_path)
            if not os.path.exists(full_path):
                return None
            with open(full_path, "rb") as f:
                return f.read()
        except Exception:
            return None
