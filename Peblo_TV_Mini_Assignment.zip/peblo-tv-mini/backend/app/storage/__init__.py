from typing import Optional
from backend.app.storage.base import Storage
from backend.app.storage.local import LocalStorage

_storage_instance: Optional[Storage] = None

def get_storage() -> Storage:
    """Returns the singleton storage instance."""
    global _storage_instance
    if _storage_instance is None:
        _storage_instance = LocalStorage()
    return _storage_instance

__all__ = ["Storage", "LocalStorage", "get_storage"]
